import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ComponentsRoutingModule } from './components-routing.module';
import { CustomerorderpendingComponent } from './dashboard/customerorder/customerorderpending/customerorderpending.component';
import { CustomerordercompleteComponent } from './dashboard/customerorder/customerordercomplete/customerordercomplete.component';
import { CustomerordercancelComponent } from './dashboard/customerorder/customerordercancel/customerordercancel.component';


@NgModule({
  declarations: [
    CustomerorderpendingComponent,
    CustomerordercompleteComponent,
    CustomerordercancelComponent
  ],
  imports: [
    CommonModule,
    ComponentsRoutingModule
  ]
})
export class ComponentsModule { }
