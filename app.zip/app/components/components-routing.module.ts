import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerorderComponent } from './dashboard/customerorder/customerorder.component'
import { PurchaseorderComponent } from './dashboard/purchaseorder/purchaseorder.component';

const routes: Routes = [
  {path: 'dashboard', component: CustomerorderComponent},
  {path: 'dashboard', component: PurchaseorderComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ComponentsRoutingModule { }
