import { Component, OnInit } from '@angular/core';
import { PurchaseorderDataService } from './../../../services/purchaseorder/purchaseorder-data.service'

@Component({
  selector: 'app-purchaseorder',
  templateUrl: './purchaseorder.component.html',
  styleUrls: ['./purchaseorder.component.css']
})
export class PurchaseorderComponent implements OnInit {

  getPurchaseOrder: any;
  getPurchaseOrderPending: any;
  getPurchaseOrderCancel: any;
  selectedTab: string | undefined;

  constructor(
    private purchaseordersData:PurchaseorderDataService
    ) {}

  ngOnInit(): void {
    this.purchaseordersData.getPurchaseOrder().subscribe((data)=>{
      this.getPurchaseOrder=data;
    })
    this.purchaseordersData.getPurchaseOrderPending().subscribe((data)=>{
      this.getPurchaseOrderPending=data;
    })
    this.purchaseordersData.getPurchaseOrderCancel().subscribe((data)=>{
      this.getPurchaseOrderCancel=data;
    })
  }

  onTabChange(tab: string) {
    this.selectedTab = tab;
  }

}
