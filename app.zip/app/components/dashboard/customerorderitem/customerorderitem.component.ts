import { Component, OnInit } from '@angular/core';
import { CustomerorderitemService } from 'src/app/services/customerorderitem/customerorderitem.service';

@Component({
  selector: 'app-customerorderitem',
  templateUrl: './customerorderitem.component.html',
  styleUrls: ['./customerorderitem.component.css']
})
export class CustomerorderitemComponent implements OnInit {

  customerorderitems: any;
  // checkBoxesMode: string = 'multiple';
  constructor(private customerorderitemsData:CustomerorderitemService) { 
    this.customerorderitemsData.customerorderitems().subscribe((data)=>{
      this.customerorderitems=data;
    })
  }
  
  ngOnInit(): void {
  }

}
