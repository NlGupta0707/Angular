import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerorderitemComponent } from './customerorderitem.component';

describe('CustomerorderitemComponent', () => {
  let component: CustomerorderitemComponent;
  let fixture: ComponentFixture<CustomerorderitemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerorderitemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerorderitemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
