import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseorderitemComponent } from './purchaseorderitem.component';

describe('PurchaseorderitemComponent', () => {
  let component: PurchaseorderitemComponent;
  let fixture: ComponentFixture<PurchaseorderitemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchaseorderitemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PurchaseorderitemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
