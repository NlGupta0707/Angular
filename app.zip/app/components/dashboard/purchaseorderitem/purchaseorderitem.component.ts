import { Component, OnInit } from '@angular/core';
import { PurchaseorderitemDataService } from 'src/app/services/purchaseorderitem/purchaseorderitem-data.service';

@Component({
  selector: 'app-purchaseorderitem',
  templateUrl: './purchaseorderitem.component.html',
  styleUrls: ['./purchaseorderitem.component.css']
})
export class PurchaseorderitemComponent implements OnInit {

  purchaseorderitems: any;
  // checkBoxesMode: string = 'multiple';
  constructor(private purchaseorderitemdatas:PurchaseorderitemDataService) { 
    this.purchaseorderitemdatas.purchaseorderitems().subscribe((data)=>{
      this.purchaseorderitems=data;
    })
  }

  ngOnInit(): void {
  }

}
