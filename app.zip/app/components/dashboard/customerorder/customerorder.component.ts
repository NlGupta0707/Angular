import { Component, OnInit } from '@angular/core';
import { CustomerorderDataService, MCustomerOreder } from 'src/app/services/customerorder/customerorder-data.service';

@Component({
  selector: 'app-customerorder',
  templateUrl: './customerorder.component.html',
  styleUrls: ['./customerorder.component.css'],
})

export class CustomerorderComponent implements OnInit {
  customerorders: any;
  customerorderspending: any;
  customerorderscancel: any;
  customerordersmobile: any;
  selectedTab: string | undefined;

  constructor(
    private customerorderData: CustomerorderDataService
  ) {}

  ngOnInit(): void {
    this.customerorderData.getCcustomerOrders().subscribe((data) => {
      this.customerorders = data;
    });
    this.customerorderData.getCcustomerOrdersPending().subscribe((data) => {
      this.customerorderspending = data;
    });
    this.customerorderData.getCcustomerOrdersCancel().subscribe((data) => {
      this.customerorderscancel = data;
    });
    this.customerorderData.customerordersmobile().subscribe((data) => {
      this.customerordersmobile = data;
    });
  }

  onTabChange(tab: string) {
    this.selectedTab = tab;
  }

}
