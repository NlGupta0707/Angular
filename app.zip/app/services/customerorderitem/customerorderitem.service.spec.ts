import { TestBed } from '@angular/core/testing';

import { CustomerorderitemService } from './customerorderitem.service';

describe('CustomerorderitemService', () => {
  let service: CustomerorderitemService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerorderitemService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
