import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerorderitemService {
  baseUrl = 'https://localhost:7081/COAuth/get-co-items';

  constructor(private http: HttpClient) {}

  customerorderitems() {
    return this.http.get(this.baseUrl);
  }
}

