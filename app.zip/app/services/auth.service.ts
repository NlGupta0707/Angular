import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl: string = 'https://localhost:7081/auth';

  constructor(private http: HttpClient) {}

  login(loginObj: any) {
    return this.http.post<any>(`${this.baseUrl}/login`, loginObj);
  }
}
export class CmOrderType {
  SR_CODE!: string;
  CC_NO: number = 0;
  T_DATE!: Date;
  AC_CODE!: string;
  AC_NAME!: string;
  A_YN: boolean = false;
  COID: number = 0;
  PO_NO!: string;
  PO_DT!: Date;
  AO_NO!: string;
  AO_DT!: Date;
  E_YN: boolean = false;
  DR_DATE!: Date;
  DR_YN: boolean = false;
  REV_NO: number = 0;
  EDATE!: Date;
  REV_REMARK!: string;
  CONO!: string;
  REV_DT!: Date;
  E_USER!: string;
  A_USER!: string;
  F_EYN: number = 0;
}


let cmorder: CmOrderType[] = [
  {
    SR_CODE: 'SR1234',
    CC_NO: 1234567890,
    T_DATE: new Date('2023-05-20'),
    AC_CODE: 'AC001',
    AC_NAME: 'John Doe',
    A_YN: true,
    COID: 9876543210,
    PO_NO: 'PO-001',
    PO_DT: new Date('2023-05-15'),
    AO_NO: 'AO-001',
    AO_DT: new Date('2023-05-10'),
    E_YN: false,
    DR_DATE: new Date('2023-05-18'),
    DR_YN: true,
    REV_NO: 2,
    EDATE: new Date('2023-05-19'),
    REV_REMARK: 'Some revision remark',
    CONO: 'CON001',
    REV_DT: new Date('2023-05-19'),
    E_USER: 'johndoe@example.com',
    A_USER: 'janedoe@example.com',
    F_EYN: 1,
  },
  {
    SR_CODE: 'SR1234',
    CC_NO: 1234567890,
    T_DATE: new Date('2023-05-20'),
    AC_CODE: 'AC001',
    AC_NAME: 'John Doe',
    A_YN: true,
    COID: 9876543210,
    PO_NO: 'PO-001',
    PO_DT: new Date('2023-05-15'),
    AO_NO: 'AO-001',
    AO_DT: new Date('2023-05-10'),
    E_YN: false,
    DR_DATE: new Date('2023-05-18'),
    DR_YN: true,
    REV_NO: 2,
    EDATE: new Date('2023-05-19'),
    REV_REMARK: 'Some revision remark',
    CONO: 'CON001',
    REV_DT: new Date('2023-05-19'),
    E_USER: 'johndoe@example.com',
    A_USER: 'janedoe@example.com',
    F_EYN: 1,
  },
  {
    SR_CODE: 'SR1234',
    CC_NO: 1234567890,
    T_DATE: new Date('2023-05-20'),
    AC_CODE: 'AC001',
    AC_NAME: 'John Doe',
    A_YN: true,
    COID: 9876543210,
    PO_NO: 'PO-001',
    PO_DT: new Date('2023-05-15'),
    AO_NO: 'AO-001',
    AO_DT: new Date('2023-05-10'),
    E_YN: false,
    DR_DATE: new Date('2023-05-18'),
    DR_YN: true,
    REV_NO: 2,
    EDATE: new Date('2023-05-19'),
    REV_REMARK: 'Some revision remark',
    CONO: 'CON001',
    REV_DT: new Date('2023-05-19'),
    E_USER: 'johndoe@example.com',
    A_USER: 'janedoe@example.com',
    F_EYN: 1,
  },
  {
    SR_CODE: 'SR1234',
    CC_NO: 1234567890,
    T_DATE: new Date('2023-05-20'),
    AC_CODE: 'AC001',
    AC_NAME: 'John Doe',
    A_YN: true,
    COID: 9876543210,
    PO_NO: 'PO-001',
    PO_DT: new Date('2023-05-15'),
    AO_NO: 'AO-001',
    AO_DT: new Date('2023-05-10'),
    E_YN: false,
    DR_DATE: new Date('2023-05-18'),
    DR_YN: true,
    REV_NO: 2,
    EDATE: new Date('2023-05-19'),
    REV_REMARK: 'Some revision remark',
    CONO: 'CON001',
    REV_DT: new Date('2023-05-19'),
    E_USER: 'johndoe@example.com',
    A_USER: 'janedoe@example.com',
    F_EYN: 1,
  },
  {
    SR_CODE: 'SR1234',
    CC_NO: 1234567890,
    T_DATE: new Date('2023-05-20'),
    AC_CODE: 'AC001',
    AC_NAME: 'John Doe',
    A_YN: true,
    COID: 9876543210,
    PO_NO: 'PO-001',
    PO_DT: new Date('2023-05-15'),
    AO_NO: 'AO-001',
    AO_DT: new Date('2023-05-10'),
    E_YN: false,
    DR_DATE: new Date('2023-05-18'),
    DR_YN: true,
    REV_NO: 2,
    EDATE: new Date('2023-05-19'),
    REV_REMARK: 'Some revision remark',
    CONO: 'CON001',
    REV_DT: new Date('2023-05-19'),
    E_USER: 'johndoe@example.com',
    A_USER: 'janedoe@example.com',
    F_EYN: 1,
  },
];

export class CustomerService{
  getCmorder(){
    return cmorder;
  }
}

