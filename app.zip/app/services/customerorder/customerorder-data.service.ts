import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CustomerorderDataService {
  baseUrl = 'https://localhost:7081/COAuth/get-all-pendingComplete-CO';
  baseUrlp = 'https://localhost:7081/COAuth/get-all-pendingComplete-CO';
  baseUrlc = 'https://localhost:7081/COAuth/get-all-pendingComplete-CO';
  constructor(private http: HttpClient) {}

  getCcustomerOrders() {
    return this.http.get(this.baseUrl);
  }
  getCcustomerOrdersPending() {
    return this.http.get(this.baseUrlp);
  }
  getCcustomerOrdersCancel() {
    return this.http.get(this.baseUrlc);
  }
  customerordersmobile(): Observable<MCustomerOreder[]> {
    const url = `${this.baseUrl}?limit=3`; // Modify the URL to limit the results to 3
    return this.http.get<any[]>(url).pipe(
      map(data => {
        return data.map((item: any) => {
          const customerOrder = new MCustomerOreder();
          customerOrder.aC_NAME = item.aC_NAME;
          customerOrder.a_USER = item.a_USER;
          customerOrder.coid = item.coid;
          return customerOrder;
        });
      })
    );
  }
}

export class MCustomerOreder {
  aC_NAME: string | undefined;
  a_USER: string | undefined;
  coid: string | undefined;
}
