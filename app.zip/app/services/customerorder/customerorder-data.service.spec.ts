import { TestBed } from '@angular/core/testing';

import { CustomerorderDataService } from './customerorder-data.service';

describe('CustomerorderDataService', () => {
  let service: CustomerorderDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerorderDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
