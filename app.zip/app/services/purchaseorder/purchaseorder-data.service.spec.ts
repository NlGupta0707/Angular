import { TestBed } from '@angular/core/testing';

import { PurchaseorderDataService } from './purchaseorder-data.service';

describe('PurchaseorderDataService', () => {
  let service: PurchaseorderDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PurchaseorderDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
