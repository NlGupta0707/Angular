import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PurchaseorderDataService {

  baseUrl = 'https://localhost:7081/POAuth/get-all-purchase-orders';
  baseUrlp = 'https://localhost:7081/POAuth/get-all-purchase-pending-orders';
  baseUrlc = 'https://localhost:7081/POAuth/get-all-purchase-cancel-orders';

  private ordersUrl = 'https://localhost:7081/POAuth/get-all-purchaseorders-item';

  constructor(private http:HttpClient) { }

  getPurchaseOrder(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }
  getPurchaseOrderPending(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrlp);
  }
  getPurchaseOrderCancel(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrlc);
  }

  getItemPurchaseOrderId(poid: number): Observable<any[]> {
    const url = `${this.ordersUrl}?poid=${poid}`;
    return this.http.get<any[]>(url);
  }



  // purchaseorders()
  // {
  //   return this.http.get(this.baseUrl);
  // }

}
