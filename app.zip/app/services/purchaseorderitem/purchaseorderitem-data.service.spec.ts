import { TestBed } from '@angular/core/testing';

import { PurchaseorderitemDataService } from './purchaseorderitem-data.service';

describe('PurchaseorderitemDataService', () => {
  let service: PurchaseorderitemDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PurchaseorderitemDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
