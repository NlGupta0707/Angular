import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PurchaseorderitemDataService {

  baseUrl = 'https://localhost:7081/POAuth/get-all-purchaseorders-item';
  
    constructor(private http: HttpClient) {}
  
    purchaseorderitems() {
      return this.http.get(this.baseUrl);
    }
}
