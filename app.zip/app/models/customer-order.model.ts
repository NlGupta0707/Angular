export class CustomerOrder {
    SR_CODE: string;
    CC_NO: number;
    T_DATE: Date;
    AC_CODE: string;
    AC_NAME: string;
    A_YN: boolean;
    COID: number;
    PO_NO: string;
    PO_DT: Date;
    AO_NO: string;
    AO_DT: Date;
    E_YN: boolean;
    DR_DATE: Date;
    DR_YN: boolean;
    REV_NO: number;
    EDATE: Date;
    REV_REMARK: string;
    CONO: string;
    REV_DT: Date;
    E_USER: string;
    A_USER: string;
    F_EYN: number;
  
    constructor(
      SR_CODE: string,
      CC_NO: number,
      T_DATE: Date,
      AC_CODE: string,
      AC_NAME: string,
      A_YN: boolean,
      COID: number,
      PO_NO: string,
      PO_DT: Date,
      AO_NO: string,
      AO_DT: Date,
      E_YN: boolean,
      DR_DATE: Date,
      DR_YN: boolean,
      REV_NO: number,
      EDATE: Date,
      REV_REMARK: string,
      CONO: string,
      REV_DT: Date,
      E_USER: string,
      A_USER: string,
      F_EYN: number
    ) {
      this.SR_CODE = SR_CODE;
      this.CC_NO = CC_NO;
      this.T_DATE = T_DATE;
      this.AC_CODE = AC_CODE;
      this.AC_NAME = AC_NAME;
      this.A_YN = A_YN;
      this.COID = COID;
      this.PO_NO = PO_NO;
      this.PO_DT = PO_DT;
      this.AO_NO = AO_NO;
      this.AO_DT = AO_DT;
      this.E_YN = E_YN;
      this.DR_DATE = DR_DATE;
      this.DR_YN = DR_YN;
      this.REV_NO = REV_NO;
      this.EDATE = EDATE;
      this.REV_REMARK = REV_REMARK;
      this.CONO = CONO;
      this.REV_DT = REV_DT;
      this.E_USER = E_USER;
      this.A_USER = A_USER;
      this.F_EYN = F_EYN;
    }
  }
  