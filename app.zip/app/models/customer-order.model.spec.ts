import { CustomerOrder } from './customer-order.model';

describe('CustomerOrder', () => {
  it('should create an instance', () => {
    expect(new CustomerOrder()).toBeTruthy();
  });
});
